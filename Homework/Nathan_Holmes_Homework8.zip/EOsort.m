% Nathan Holmes
% 11/10/2017
% Section 208
% Homework 8

function [cellOut, varargout] = EOsort(leCell)
% Sorts a cell of numbers to one cell of even and one cell of odd
% INPUT: leCell     --  cell of numbers to be sorted to even and odd
    % only integers can be considered even or odd
% OUTPUT: cellOut   --  output cell with first cell even and second cell odd

tic; % starts timer

tester = rem(cell2mat(leCell),2); % returns cell; makes leCell a matrix of numbers; divides all numbers by 2;
% where there is a remainder of 1 there is an odd number

even = cell2mat(leCell(tester == 0)); % makes numeric matrix; extracts even numbers using indexes
odd = cell2mat(leCell(tester == 1)); % numeric matrix; extracts odd numbers using indexes
cellOut = {even,odd};

varargout = num2cell(toc); % stops timer and stores it as time
end