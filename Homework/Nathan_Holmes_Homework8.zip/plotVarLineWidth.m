% Nathan Holmes
% 11/10/2017
% Section 208
% Homework 8

function plotVarLineWidth(x,y,line_width,color)
% plots y vs x with specified line width and color
% INPUTS:   x and y     --  data points
%           line_width  --  thickness of line to use
%           color       --  an RGB color
plot(x,y,'LineWidth',line_width,'Color',color);
leTitle = sprintf('Line Width = %d, Color = [%.1f %.1f %.1f]',[line_width,double(color)]);
    % stores the title as a string for use as the plot title 
    % Line width displays as an integer
    % RGB color displays to one decimal point
title(leTitle);
end