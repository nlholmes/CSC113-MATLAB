% Name: Nathan Holmes
% Section: 208
% Date:  10/13/2017
% In-Lab 06

clear all; close all; clc % clear functions
%% Instructor-Guided Portion
%% Problem 1 - Wolfpack Word Search 
% Create a random matrix of letters c through r, then add 'WOLFPACK'.
randomMat = char(randi(['a'+2,'a'+17],8,5));
% Replacing WOLFPACK
randomMat(:,3) = 'WOLFPACK';

% Creating char() matrix: (c=99, r=114)


% Display final search:
disp(randomMat);

%% Problem 2 - Add Blank Space 
% Create function convertToBlank() to remove underscores and call below.
str = 'They_call_it_a_Royale_with_cheese';
str2 = 'YOU_SHOULD_START_PROJECT_2';


% Calling function:
out1 = convertToBlank(str);
out2 = convertToBlank(str2);
disp(out1);
disp(out2);

%% Problem 3 - I heard you like Cells... 
% Create the given arrays within a larger cell array and perform the
% operations.

% From IL sheet
A = [101 139 189; 22 44 66; 206 407 429];
B = {'Alwin','Casey','Matthew';'Andrew','Charlotte','Brandon';'Andy', ...
    'John-Michael','Raven';'Anna','Jonathan','Seth';'Alper', ...
    'Kevin','Esther'};
C = int8([1;1;3]);
sample_cell = {A,B,C};
% a. Extract A from cell array:
Acell = sample_cell(1);
Amat = sample_cell{1};

% b. Extract your TAs:
theGoodOne = sample_cell{2}{4,2};
theOtherOne = sample_cell{2}{1,1};

% c. Perform operation:
value = sample_cell{1}(2,3)./double(sample_cell{3}(3))

% d. Visualize sample_cell:
cellplot(sample_cell);

%% Problem 4 - Data Conversion
% Create the function typeConvert() to store a given variable as different
% data types.

out = typeConvert(1000);
celldisp(out);

% Call the function:




%% Independent Portion

